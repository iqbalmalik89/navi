<?php 
define('CNF_APPNAME','Sximo 5.1 LTS Laravel');
define('CNF_APPDESC','PHP Application Builder and Platform IDE');
define('CNF_COMNAME','My Company Name');
define('CNF_EMAIL','info@mail.com');
define('CNF_METAKEY','my site , my company  , Larvel Crud');
define('CNF_METADESC','Write description for your site');
define('CNF_GROUP','3');
define('CNF_ACTIVATION','confirmation');
define('CNF_MULTILANG','1');
define('CNF_LANG','en');
define('CNF_REGIST','true');
define('CNF_FRONT','true');
define('CNF_RECAPTCHA','false');
define('CNF_THEME','sximone');
define('CNF_RECAPTCHAPUBLICKEY','');
define('CNF_RECAPTCHAPRIVATEKEY','');
define('CNF_MODE','production');
define('CNF_LOGO','backend-logo.png');
?>